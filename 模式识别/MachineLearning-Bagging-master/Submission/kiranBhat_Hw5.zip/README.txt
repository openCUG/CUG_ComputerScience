Name: Kiran Bhat Gopalakrishna
NetId: kxb140230

*************************************************************************************************
To Compile:

javac Machine_Learning_Hw5.java

*************************************************************************************************

To Run:

java Machine_Learning_Hw5 <path to traning directory> <path to test file>

Program runs on any kind of train files and test files (However, train files and test file must be same as 
mentioned in the Programm Report) But the train and test Files are provided for your reference.

*************************************************************************************************
Sample o/p


Number of training Sets in Bagging : 50

Accuracy on test  Set :86.69950738916256

*******************************************************************************************************

Programm Description(Details present in Program Report):

I/p: Path to directory containing train files and path to test files
o/p: Accuracy is displayed after using the bagging.
